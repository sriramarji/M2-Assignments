import { Injectable } from '@angular/core';
import { Movie } from "./movie";
import { HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MovieService {

  constructor(private httpClient:HttpClient) { 
    
   this.getMovieDetails().subscribe(data => this.movieList = data);
  }

  movieList:Array<Movie>=[];
  url:string="/assets/movies.json";

  getMovieDetails():any{
    return this.httpClient.get<Movie>(this.url);
  }

  setMovieDetails(movie:Movie){
    this.movieList.push(movie);
  }
  movieList1:any[]

  search(data):any[]{
    this.movieList1 = [];
    console.log(data);

    console.log(data.genre);
    for(let movie of this.movieList){
      if(movie.genre == data.genre){
        this.movieList1.push(movie);
      }
    }
    return this.movieList1;
  }
}
